<?php $__env->startSection('title', 'Boe Home'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app2.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="project">
      <?php if(isset($projects)): ?>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
        <div class="card-details">
          <p class="text-title"> <?php echo e($project->subject); ?></p>
          <p class="text-title"><?php echo e($project->member1); ?>, <?php echo e($project->member2); ?>, <?php echo e($project->member3); ?></p>
          <p class="text-title"><?php echo e($project->enc); ?></p>
          <p class="text-title"><?php echo e($project->LMD); ?></p>
        </div>
        <a href="<?php echo e(route('app.review', ['id' => $project->id])); ?>">More Info</a>
      </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      

        </section>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/memOussama/liveSite/resources/views/app/acc_projects.blade.php ENDPATH**/ ?>