<header>
        <div id="menu-bar" class="fas fa-bars" onclick="showmenu()"></div>
        <div class="logo"><img src="photo/logo.png" ></div>
        <div class="search-box">
            <from action="">
                <input type="text" name="search" id="srch" placeholder="Search">
                <button type="submit"><i class="fas fa-search"></i></button>
            </from>
        </div>
        <nav class="navbar">
            <a href="<?php echo e(route('app.home')); ?>" id="n">home</a>
            <a href="<?php echo e(route('app.projects')); ?>" >Projects</a>
            <a href="static.html"  class="h">Dashboard</a>
            <a href="<?php echo e(route('app.ideas')); ?>">Ideas</a>
            <a href="<?php echo e(route('app.about')); ?>">About</a>          
        </nav>        
    </header><?php /**PATH /home/hexzar/Desktop/memOussama/liveSite/resources/views/admin/header.blade.php ENDPATH**/ ?>