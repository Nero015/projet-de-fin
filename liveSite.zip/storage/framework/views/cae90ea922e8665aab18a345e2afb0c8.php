<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="static">

<h1>Statistic :</h1>
<div class="control">
    <div class="cards">
        
        <div class="card red">
            <p class="tip">Total project</p>
            <p class="second-text"><?php echo e($projectsNum); ?></p>
        </div>
   <a href="#pending">
        <div class="card blue">
            <p class="tip">pending</p>
            <p class="second-text"><?php echo e($pendingProjectsNum); ?></p>
        </div>
    </a>
        <div class="card red">
            <p class="tip">accepted</p>
            <p class="second-text"><?php echo e($accptedProjectsNum); ?></p>
        </div>
        <a href="#unaccpted">
        <div class="card blue">
            <p class="tip">unaccpted</p>
            <p class="second-text"><?php echo e($rejectedProjectsNum); ?></p>
        </div>
    </a>
        <a href="#singendup">
        <div class="card red">
            <p class="tip">singendup</p>
            <p class="second-text"><?php echo e($users); ?></p>
        </div>
    </a>
    </div>
</div>

</section>

<section class="pending" id="pending">
<h1>pending list</h1>
<?php if(isset($pendingProjectsList)): ?>
<?php $__currentLoopData = $pendingProjectsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendingProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('app.admin.review', ['id' => $pendingProject->id])); ?>" target="_blank"><div class="section">
    <h2><?php echo e($pendingProject->subject); ?></h2>
    <p><spam>Student Name</spam>: <?php echo e($pendingProject->member1); ?> | 
        <spam> Supervisor</spam>: <?php echo e($pendingProject->enc); ?> |
        <spam> Email</spam>: <?php echo e($pendingProject->user->email); ?> | 
        <spam> Time of Sending</spam>: <?php echo e($pendingProject->created_at); ?></p>           
  </div></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>There are no pending Projects at The Moment</p>
<?php endif; ?>

</section>

<section class="unaccpted" id="unaccpted">
<h1>Unaccepted list</h1>

<?php if(isset($rejectedProjects)): ?>
<?php $__currentLoopData = $rejectedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rejectedProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="#" target="_blank"><div class="section">
    <h2><?php echo e($rejectedProject->subject); ?></h2>
    <p><spam>Student Name</spam>: <?php echo e($rejectedProject->member1); ?> | 
        <spam> Supervisor</spam>: <?php echo e($rejectedProject->enc); ?> |
        <spam> Email</spam>: <?php echo e($rejectedProject->user->email); ?> | 
        <spam> Time of Sending</spam>: <?php echo e($rejectedProject->created_at); ?></p>           
  </div></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>There are no rejected Projects at The Moment</p>
<?php endif; ?>



</section>

<section class="singendup" id="singendup">
<h1>singendup</h1>

<div class="activity">
    <div class="activity-data">

        <div class="email">
            <span class="data-title">Email</span>
            <?php if(isset($usersData)): ?>
                <?php $__currentLoopData = $usersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="data-list"><?php echo e($userData->email); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
       
        <div class="data project">
            <span class="data-title">project</span>
            <?php if(isset($usersData)): ?>
                <?php $__currentLoopData = $usersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="data-list"><?php echo e(count($userData->project)); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <div class="data joined">
            <span class="data-title">Joined</span>
            <?php if(isset($usersData)): ?>
                <?php $__currentLoopData = $usersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="data-list"><?php echo e($userData->created_at); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/memOussama/liveSite/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>