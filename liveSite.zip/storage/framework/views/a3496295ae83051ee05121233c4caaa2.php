<header>
        <div id="menu-bar" class="fas fa-bars" onclick="showmenu()"></div>
        <div class="logo"><img src="<?php echo e(asset('images/logo.jpg')); ?>" ></div>
        <div class="search-box">
            <from action="">
                <input type="text" name="search" id="srch" placeholder="Search...">
                <button type="submit"><i class="fas fa-search"></i></button>
            </from>
        </div>
        <nav class="navbar">
            <a href="<?php echo e(route('app.home')); ?>" class="h" id="n">home</a>
            <a href="<?php echo e(route('app.projects')); ?>">Projects</a>
            <a href="<?php echo e(route('app.ideas')); ?>">Ideas</a>
            <a href="<?php echo e(route('app.about')); ?>">About</a> 
            <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('app.login')); ?>"> Login  </a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('app.submittions')); ?>">Submitions</a>
            <a href="<?php echo e(route('app.proc.logout')); ?>">Logout</a>
            <?php endif; ?>
        </nav>        
</header> <?php /**PATH /home/hexzar/Desktop/memOussama/liveSite/resources/views/app/header.blade.php ENDPATH**/ ?>