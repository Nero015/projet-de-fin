<?php $__env->startSection('title', 'Boe Home'); ?>
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="post-form">
        <i class="fas fa-times" id="form-close" onclick="hideform()"></i>
        <form action="<?php echo e(route('app.pro.ideas')); ?>" method="POST">
            <h3>add post</h3>
            <div class="form-container">
                <form class="form">
                  <?php echo csrf_field(); ?>
                   <div class="form-group">
                        <label for="email">Titel</label>
                        <input required="" name="title" id="titel" type="text">
                    </div>
                    <div class="form-group">
                        <label for="textarea">How Can We Help You?</label>
                        <textarea required="" cols="50" rows="10" id="textarea" name="subject">          </textarea>
                    </div>
                    <button type="submit" class="form-submit-btn">Submit</button>
                   <div> <input type="checkbox" id="showmyemail">
                    <label for="remmember"> show my email</label></div>
                    <p>Posting project thesis ideas is helping to students and ur help would be mentioned in their projects</p>

                </form>
            </div>
        </form>
    </div>
    <section class="post"> 
        <button class="button2" onclick="showform()">add post</button>
    </section>
        <?php if(isset($error)): ?>
        <p style="color: red"><?php echo e($error); ?></p>
        <?php elseif(isset($success)): ?>
        <p style="color: green"><?php echo e($success); ?></p>
        <?php endif; ?>  
    <div class="container">

        <?php if(isset($ideas) && $ideas->isNotEmpty()): ?>
        <?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card">
            <div class="card-details">
              <p class="text-title"><?php echo e($idea->title); ?></p>
              <p class="text-body"><?php echo e($idea->subject); ?></p>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <p>No Ideas To Show at the Moment</p>
        <?php endif; ?>
        

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hexzar/Desktop/memOussama/liveSite/resources/views/app/idea.blade.php ENDPATH**/ ?>